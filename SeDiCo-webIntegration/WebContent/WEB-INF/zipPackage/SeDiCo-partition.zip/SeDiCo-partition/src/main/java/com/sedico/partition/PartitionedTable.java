package com.sedico.partition;

import com.sedico.sql.*;

public class PartitionedTable {
    private final Table table;
    private final int partition;

    public PartitionedTable(Table table, int partition) {
        this.table = table;
        this.partition = partition;
    }

    public Table getTable() {
        return table;
    }

    public int getPartition() {
        return partition;
    }
}
