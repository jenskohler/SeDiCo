package com.sedico.commands;

/**
 * Diese Klasse implementiert das Interface ConsoleCommand
 * @author jens
 *
 */
public interface ConsoleCommand {
    /**
     * Abstrakte Methode getKeys
     * @return String[]
     */
	String[] getKeys();
	/**
	 * Abstrakte Methode getUsage
	 * @return String
	 */
    String getUsage();
    /**
     * Abstrakte Methode Execute
     * @param args - String of arguments
     */
    void Execute(String args[]);
}
