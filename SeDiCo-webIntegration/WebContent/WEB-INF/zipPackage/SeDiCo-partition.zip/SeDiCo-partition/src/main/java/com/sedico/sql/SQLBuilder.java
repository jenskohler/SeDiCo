package com.sedico.sql;

import java.util.*;

public interface SQLBuilder {
    String buildCreateTable(Table table, String databaseName);

    List<String> buildInserts(Table table, String databaseName);

    List<String> buildDeletes(Table table, String databaseName);

    List<String> buildUpdates(Table table, String databaseName);

    String buildSelect(Table table, String databaseName);
}
