package com.sedico.partition;

import com.sedico.Configuration;
import com.sedico.sql.Table;
import com.sedico.sql.reading.*;

public class TableReader {

    private final SQLReaderStrategy readerStrategy;

    public TableReader() {
        PartitionDescriptor partition = Configuration.getSecondaryPartition();
        readerStrategy = SQLReaderStrategyFactory.createSqlReaderStrategy(partition);
    }

    public Table select(Table table) {
        table = readerStrategy.queryTable(table);
        return table;
    }
}
