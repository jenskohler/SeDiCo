package com.sedico.sql.importing;

import com.sedico.sql.Table;

public interface SQLImportStrategy {
    Table fetchTable();
}
