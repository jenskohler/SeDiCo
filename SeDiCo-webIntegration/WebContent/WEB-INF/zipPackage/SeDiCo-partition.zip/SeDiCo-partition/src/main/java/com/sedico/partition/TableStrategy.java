package com.sedico.partition;

import com.sedico.sql.*;

public interface TableStrategy {
    Iterable<PartitionedTable> getPartitionedTables(Table table);
}
