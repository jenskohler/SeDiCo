package com.sedico.sql;

import org.hibernate.dialect.*;

public class MySQLBuilder extends SQLBuilderBase {

    private Dialect dialect = new SedicoMySQL5InnoDBDialect();

    @Override
    protected Dialect getDialect() {
        return dialect;
    }
}
