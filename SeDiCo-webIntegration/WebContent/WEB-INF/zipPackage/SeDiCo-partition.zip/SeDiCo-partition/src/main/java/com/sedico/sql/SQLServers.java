package com.sedico.sql;

public enum SQLServers {
    Oracle,
    MySQL
}
