package com.sedico.sql.writing;

import com.sedico.sql.*;

public interface SQLWriterStrategy {
    void createTable(Table table);

    void insertTable(Table table);

    void deleteTable(Table table);

    void updateTable(Table table);
}
