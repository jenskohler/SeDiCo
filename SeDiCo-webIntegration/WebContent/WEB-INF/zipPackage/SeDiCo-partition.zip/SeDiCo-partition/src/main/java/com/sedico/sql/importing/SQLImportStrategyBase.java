package com.sedico.sql.importing;

import com.sedico.Configuration;
import com.sedico.sql.*;

import java.sql.*;
import java.util.*;

public class SQLImportStrategyBase implements SQLImportStrategy {
    private SqlConnectionDescriptor connectionDescriptor = Configuration.getSource();

    @Override
    public Table fetchTable() {
        List<Row> rows = new ArrayList();
        List<ColumnDescriptor> columns = new ArrayList();
        try {
            try(Connection connection = DriverManager.getConnection(connectionDescriptor.getConnectionString(), connectionDescriptor.getUser(), connectionDescriptor.getPassword())) {
                columns = getColumns(connection);
                rows = selectData(columns, connection);
            }
        } catch (SQLException e3) {
            System.out.println(e3.getMessage());
        }
        return createTable(rows, columns);
    }

    private Table createTable(List<Row> rows, List<ColumnDescriptor> columnDescriptors) {
        return new Table(connectionDescriptor.getTable(), rows, columnDescriptors);
    }

    private List<Row> selectData(List<ColumnDescriptor> columnDescriptorss, Connection connection) throws SQLException {
        String query = createQueryForColumns(columnDescriptorss);
        List<Row> tableValues = new ArrayList();
        Statement statement = connection.createStatement();
        try(ResultSet res = statement.executeQuery(query)) {
            while (res.next()) {
                List<Column> columns = new ArrayList();
                for(ColumnDescriptor column : columnDescriptorss) {
                    String value = res.getString(column.getColumnName());
                    columns.add(new Column(column.getColumnName(), value));
                }
                Row columnValues = new Row(columns);
                tableValues.add(columnValues);
            }
        }
        return tableValues;
    }

    private String createQueryForColumns(List<ColumnDescriptor> columns) {
        String columnNames = "";
        for(ColumnDescriptor column : columns) {
            columnNames += column.getColumnName() + ", ";
        }
        columnNames = columnNames.substring(0, columnNames.length() - 2);
        String query = String.format("SELECT %s FROM %s.%s", columnNames, connectionDescriptor.getDatabase(), connectionDescriptor.getTable());
        return query;
    }

    private List<ColumnDescriptor> getColumns(Connection connection) throws SQLException {
        List<String> primaryColumns = getPrimaryKeyColumns(connection);
        List<ColumnDescriptor> columns = new ArrayList();
        try(ResultSet res = connection.getMetaData().getColumns(null, connectionDescriptor.getDatabase(), connectionDescriptor.getTable(), null)) {
            while (res.next()) {
                ColumnDescriptor column;
                int columnType = res.getInt("DATA_TYPE");
                long columnSize = res.getLong("COLUMN_SIZE");
                int columnDigits = res.getInt("DECIMAL_DIGITS");

                if (primaryColumns.contains(res.getString("COLUMN_NAME"))) {
                    column = new PrimaryColumnDescriptor(res.getString("COLUMN_NAME"), columnType, columnSize, columnDigits);
                }
                else {
                    column = new ColumnDescriptor(res.getString("COLUMN_NAME"), columnType, columnSize, columnDigits);
                }
                columns.add(column);
            }
        }
        return columns;
    }

    private List<String> getPrimaryKeyColumns(Connection connection) throws SQLException {
        List<String> columns = new ArrayList();
        try(ResultSet res = connection.getMetaData().getPrimaryKeys(null, connectionDescriptor.getDatabase(), connectionDescriptor.getTable())) {
            while (res.next()) {
                columns.add(res.getString("COLUMN_NAME"));
            }
        }
        return columns;
    }
}
