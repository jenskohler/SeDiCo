package com.sedico.sql.writing;

import com.sedico.partition.*;

import java.util.*;

public class SQLWriterStrategyFactory {

    public static List<SQLWriterStrategy> createSqlWriterStrategies(List<PartitionDescriptor> partitions) {
        List<SQLWriterStrategy> strategies = new ArrayList();
        for(PartitionDescriptor partition : partitions) {
            strategies.add(createSqlWriterStrategy(partition));
        }
        return strategies;
    }

    public static SQLWriterStrategy createSqlWriterStrategy(PartitionDescriptor partition) {
        switch(partition.getServerType()) {
            case Oracle:
                return new OracleSQLWriterStrategy(partition);
            case MySQL:
                return new MySQLWriterStrategy(partition);
        }
        throw new Error("Es gibt keine WriteStrategy für diesen SQL-Server-Typ.");
    }
}
