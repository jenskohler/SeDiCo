package com.sedico.sql.writing;

import com.sedico.partition.*;
import com.sedico.sql.*;

import java.sql.*;
import java.util.*;

public abstract class SQLWriterStrategyBase implements SQLWriterStrategy {

    private final PartitionDescriptor settings;

    protected SQLWriterStrategyBase(PartitionDescriptor settings) {
        this.settings = settings;
    }

    @Override
    public void createTable(Table table) {
        Table newTable = new Table(settings.getTable(), table.getRows(), table.getColumnDescriptors());
        SQLBuilder builder = createSQLBuilder();
        String create = builder.buildCreateTable(newTable, settings.getDatabase());
        List<String> creates = new ArrayList();
        creates.add(create);
        execute(creates);
    }

    @Override
    public void insertTable(Table table) {
        Table newTable = new Table(settings.getTable(), table.getRows(), table.getColumnDescriptors());
        
        SQLBuilder builder = createSQLBuilder();
        List<String> inserts = builder.buildInserts(newTable, settings.getDatabase());
        execute(inserts);
    }

    @Override
    public void deleteTable(Table table) {
        Table newTable = new Table(settings.getTable(), table.getRows(), table.getColumnDescriptors());
        SQLBuilder builder = createSQLBuilder();
        List<String> deletes = builder.buildDeletes(newTable, settings.getDatabase());
        execute(deletes);
    }

    @Override
    public void updateTable(Table table) {
        Table newTable = new Table(settings.getTable(), table.getRows(), table.getColumnDescriptors());
        SQLBuilder builder = createSQLBuilder();
        List<String> updates = builder.buildUpdates(newTable, settings.getDatabase());
        execute(updates);
    }

    private void execute(List<String> statementTexts) {
        try {
            try(Connection connection = DriverManager.getConnection(settings.getConnectionString(), settings.getUser(), settings.getPassword())) {
                Statement statement = connection.createStatement();
                for (String statementText : statementTexts) {
                    statement.addBatch(statementText);
                }
                statement.executeBatch();
                connection.close();
            }
        } catch (SQLException e3) {
            System.out.println(e3.getMessage());
        }
    }

    protected abstract SQLBuilder createSQLBuilder();
}
