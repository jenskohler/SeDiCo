package com.sedico.sql.writing;

import com.sedico.partition.*;
import com.sedico.sql.OracleSQLBuilder;
import com.sedico.sql.SQLBuilder;

public class OracleSQLWriterStrategy extends SQLWriterStrategyBase {

    public OracleSQLWriterStrategy(PartitionDescriptor settings) {
        super(settings);
    }

    @Override
    protected SQLBuilder createSQLBuilder() {
        return new OracleSQLBuilder();
    }
}
