package com.sedico.sql;

import org.hibernate.dialect.*;

import java.sql.Types;

public class SedicoMySQL5InnoDBDialect extends MySQL5InnoDBDialect {
    public SedicoMySQL5InnoDBDialect() {
        //aus unerklärlichen Gründen fehlt dieser Datentyp in Hibernate, was zu einer Exception führt,
        //daher hier manuell hinzugefügt
        super();
    	registerColumnType(Types.DECIMAL, "decimal($p,$s)");
        
        
    }
}
