package com.sedico.sql;

import java.util.*;

import org.hibernate.dialect.Dialect;

public class Table {
    private final String tableName;
    private final List<Row> rows;
    private final List<ColumnDescriptor> columnDescriptors;
    private final List<ColumnDescriptor> primaryColumnDescriptors;

    public Table(String tableName, List<Row> rows, List<ColumnDescriptor> columnDescriptors) {
        if (columnDescriptors.size() == 0) {
            throw new IllegalArgumentException("Es wurden keine ColumnDescriptors übergeben.");
        }

        this.tableName = tableName;
        this.rows = rows;
       
        this.columnDescriptors = new ArrayList();
        this.primaryColumnDescriptors = new ArrayList();
        for (ColumnDescriptor descriptor : columnDescriptors) {
            if (descriptor.isPrimaryKey()) {
            	
                this.primaryColumnDescriptors.add(descriptor);
            	
            }
            else {
                this.columnDescriptors.add(descriptor);
               
            }
        }

        if (primaryColumnDescriptors.size() == 0) {
            throw new IllegalArgumentException("Unter den ColumnDescriptors befand sich kein Primary Key. Es sind nur Tabellen mit PK zulässig.");
        }
    }

    public String getTableName() {
        return tableName;
    }

    public List<Row> getRows() {
        return rows;
    }

    public List<ColumnDescriptor> getColumnDescriptors() {
        List<ColumnDescriptor> descriptors = new ArrayList();
        descriptors.addAll(primaryColumnDescriptors);
        descriptors.addAll(columnDescriptors);
        return descriptors;
    }

    public List<ColumnDescriptor> getValueColumnDescriptors() {
        return columnDescriptors;
    }

    public List<ColumnDescriptor> getPrimaryColumnDescriptors() {
        return primaryColumnDescriptors;
    }

    public ColumnDescriptor getColumnDescriptor(String columnName) {
        for(ColumnDescriptor descriptor : getColumnDescriptors()) {
            if (descriptor.getColumnName().equals(columnName)) {
                return descriptor;
            }
        }
        return null;
    }
}
