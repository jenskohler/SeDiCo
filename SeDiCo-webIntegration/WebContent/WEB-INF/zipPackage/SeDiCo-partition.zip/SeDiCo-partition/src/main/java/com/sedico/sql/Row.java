package com.sedico.sql;

import java.util.*;

public class Row {
    private final Map<String, Column> columns = new HashMap();

    public Row(List<Column> columns) {
        for (Column column : columns) {
            this.columns.put(column.getColumnName(), column);
        }
    }

    public Collection<Column> getColumns() {
        return columns.values();
    }

    public Column getColumn(String columnName) {
        if(columns.containsKey(columnName)) {
            return columns.get(columnName);
        }

        return null;
    }
}
