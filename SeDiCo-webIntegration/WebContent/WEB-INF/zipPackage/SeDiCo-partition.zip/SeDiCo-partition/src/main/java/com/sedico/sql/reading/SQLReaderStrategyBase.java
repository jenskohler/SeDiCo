package com.sedico.sql.reading;

import com.sedico.partition.PartitionDescriptor;
import com.sedico.sql.*;

import java.sql.*;
import java.util.*;

public abstract class SQLReaderStrategyBase implements SQLReaderStrategy {
    private final PartitionDescriptor settings;

    public SQLReaderStrategyBase(PartitionDescriptor settings) {
        this.settings = settings;
    }

    @Override
    public Table queryTable(Table table) {
        SQLBuilder builder = createSQLBuilder();
        String select = builder.buildSelect(table, settings.getDatabase());
        List<Row> rows = new ArrayList();
        Row row = execute(select, table);
        rows.add(row);

        return new Table(table.getTableName(), rows, table.getColumnDescriptors());
    }

    protected abstract SQLBuilder createSQLBuilder();

    private Row execute(String statementText, Table table) {
        List<Column> columns = new ArrayList();
        try {
            try(Connection connection = DriverManager.getConnection(settings.getConnectionString(), settings.getUser(), settings.getPassword())) {
                Statement statement = connection.createStatement();
                try(ResultSet resultSet = statement.executeQuery(statementText)) {
                    while(resultSet.next()) {
                        for (ColumnDescriptor descriptor : table.getValueColumnDescriptors()) {
                            Object value = resultSet.getObject(descriptor.getColumnName());
                            System.out.println("ADDING column: " + descriptor.getColumnName() + " WITH value: " +value);
                            columns.add(new Column(descriptor.getColumnName(), value));
                        }
                    }
                }
            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        Row row = new Row(columns);
        return row;
    }
}
