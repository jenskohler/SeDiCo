package com.sedico.sql.reading;

import com.sedico.partition.PartitionDescriptor;

import java.util.*;

public class SQLReaderStrategyFactory {

    public static List<SQLReaderStrategy> createSqlReaderStrategies(List<PartitionDescriptor> partitions) {
        List<SQLReaderStrategy> strategies = new ArrayList();
        for(PartitionDescriptor partition : partitions) {
            strategies.add(createSqlReaderStrategy(partition));
        }
        return strategies;
    }

    public static SQLReaderStrategy createSqlReaderStrategy(PartitionDescriptor partition) {
        switch(partition.getServerType()) {
            case Oracle:
                return new OracleSQLReaderStrategy(partition);
            case MySQL:
                return new MySQLReaderStrategy(partition);
        }
        throw new Error("Dieser Servertyp hat keine passenden Reader-Strategie.");
    }
}
