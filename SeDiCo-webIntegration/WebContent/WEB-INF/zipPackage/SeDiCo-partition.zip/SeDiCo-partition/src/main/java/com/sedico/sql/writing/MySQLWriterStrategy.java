package com.sedico.sql.writing;

import com.sedico.partition.*;
import com.sedico.sql.MySQLBuilder;
import com.sedico.sql.SQLBuilder;

public class MySQLWriterStrategy extends SQLWriterStrategyBase {

    public MySQLWriterStrategy(PartitionDescriptor settings) {
        super(settings);
    }

    @Override
    protected SQLBuilder createSQLBuilder() {
        return new MySQLBuilder();
    }
}
