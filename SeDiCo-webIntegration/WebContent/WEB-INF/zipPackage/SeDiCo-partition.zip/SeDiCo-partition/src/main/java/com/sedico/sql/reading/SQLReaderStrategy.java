package com.sedico.sql.reading;

import com.sedico.sql.Table;

public interface SQLReaderStrategy {
    Table queryTable(Table table);
}
