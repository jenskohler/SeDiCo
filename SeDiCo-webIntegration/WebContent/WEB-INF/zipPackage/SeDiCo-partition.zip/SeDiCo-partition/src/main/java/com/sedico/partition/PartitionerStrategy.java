package com.sedico.partition;

import com.sedico.sql.*;

public interface PartitionerStrategy {
    int getTotalPartitions();
    Iterable<Column> getColumnsForPartition(int currentPartition, Table table, Row row);
}
