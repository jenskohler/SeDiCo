package com.sedico.sql;

import org.hibernate.dialect.*;

public class OracleSQLBuilder extends SQLBuilderBase {

    private Dialect dialect = new SedicoOracle10gInnoDBDialect();

    @Override
    protected Dialect getDialect() {
        return dialect;
    }
}
