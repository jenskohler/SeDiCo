package com.sedico.sql.reading;

import com.sedico.partition.PartitionDescriptor;
import com.sedico.sql.*;

public class OracleSQLReaderStrategy extends SQLReaderStrategyBase {
    public OracleSQLReaderStrategy(PartitionDescriptor partition) {
        super(partition);
    }

    @Override
    protected SQLBuilder createSQLBuilder() {
        return new OracleSQLBuilder();
    }
}
