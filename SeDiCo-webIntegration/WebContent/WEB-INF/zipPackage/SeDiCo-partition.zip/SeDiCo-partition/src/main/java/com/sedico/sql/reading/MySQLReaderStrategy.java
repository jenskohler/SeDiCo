package com.sedico.sql.reading;

import com.sedico.partition.PartitionDescriptor;
import com.sedico.sql.*;

public class MySQLReaderStrategy extends SQLReaderStrategyBase {
    public MySQLReaderStrategy(PartitionDescriptor partition) {
        super(partition);
    }

    @Override
    protected SQLBuilder createSQLBuilder() {
        return new MySQLBuilder();
    }
}
